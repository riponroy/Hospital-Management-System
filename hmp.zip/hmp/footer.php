<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/footer.css">
  </head>
  <body>
    <footer>
      <div class="ft">
      <p>© 2018 Ripon roy & White Health. All Rights Reserved.
Privacy and Patient Rights Terms of Use Notice of Non-Discrimination</p>
    </div>
    </footer>
  </body>
</html>
